package assessment1package;

public class except extends Exception {
    

	public except(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

